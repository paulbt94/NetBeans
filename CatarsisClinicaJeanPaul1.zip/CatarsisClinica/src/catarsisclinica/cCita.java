/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catarsisclinica;
/**
 *
 * @author pauls
 */
public class cCita {
    public String Nombre;
    public String Telefono;
    public String Cedula;
    public String Correo;
    public String Padecimiento;
    public String Recomendaciones;
    public int Estado = 0;
    
    
    
}
